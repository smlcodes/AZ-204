 ## Requirements for demos
 Download and install the following packages to support the demos in this course
 1. Install Azure CLI - https://docs.microsoft.com/en-us/cli/azure/install-azure-cli 
 1. Install Azure PowerShell Az Module - https://docs.microsoft.com/en-us/powershell/azure/install-az-ps
 1. Install docker - https://docs.docker.com/desktop/#download-and-install 
 1. Install dotnet core sdk - https://dotnet.microsoft.com/download/dotnet-core
