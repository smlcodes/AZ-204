// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.EventGrid.Models;
using Microsoft.Azure.WebJobs.Extensions.EventGrid;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using System.IO;
using System.Threading.Tasks;

using Newtonsoft.Json.Linq;

using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;

namespace com.codemilltech
{
    public static class Grayscale
    {
        [FunctionName("Grayscale")]
        public static async Task Run(
            [EventGridTrigger]EventGridEvent eventGridEvent, 
            [Blob("{data.url}", FileAccess.Read)] Stream inputBlobStream,          
            ILogger log)
        {    
            log.LogInformation($"Subject: {eventGridEvent.Subject}");
            
            try
            {                        
                var createdBlobInfo = ((JObject)eventGridEvent.Data)
                    .ToObject<StorageBlobCreatedEventData>();

                var createdBlobName = (new BlobClient(new Uri(createdBlobInfo.Url))).Name;
                
                var outputBlobServiceClient = new BlobServiceClient(
                    Environment.GetEnvironmentVariable("AzureWebJobsStorage")
                );

                var outputBlobContainerClient = outputBlobServiceClient
                    .GetBlobContainerClient("grayscale");
            
                using (Image image = Image.Load(inputBlobStream))
                {       
                    using (var outputBlobStream = new MemoryStream())                 
                    {
                        image.Mutate(x => x.Grayscale());
                        await image.SaveAsPngAsync(outputBlobStream);

                        outputBlobStream.Position = 0;                    

                        // save to Azure storage
                        await outputBlobContainerClient
                            .UploadBlobAsync(createdBlobName, outputBlobStream);                        
                    }
                }                            
            }
            catch (Exception ex)
            {
                log.LogError(ex,"cannot convert");
            }            
        }
    }
}
