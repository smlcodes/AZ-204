namespace SendEvent
{
    public class NewAccountMessage
    {
        public string AccountName { get; set; }
        public string SourceSystem { get; set; }
    }
}