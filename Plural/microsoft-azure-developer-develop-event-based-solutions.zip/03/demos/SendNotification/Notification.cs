using System;

namespace SendNotification
{
    public class Notification 
    {
        public string NotificationText { get; set; }
    }
}