﻿using System;
namespace RedisCache.Models
{
    public class CacheModel
    {
        public string CacheLog { get; internal set; }
        public string CacheClients { get; internal set; }
    }
}
