﻿using System;
using StackExchange.Redis;

namespace RedisConnections
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Redis retry example");
          

            Console.ReadKey();
            
        }

     
    }

  
}
