Hi Microsoft Azure Developer,

before you run this .NET application, please set the _connectionString variable in the Program.cs file
to the connection string of your Storage Account. 

I've created a TODO comment for you for this task in the Program.cs file.

If you have any questions, please ask those questions in the discussion tab on the homepage of this course at www.pluralsight.com.

Thank you,
Thomas Claudius Huber
www.thomasclaudiushuber.com
